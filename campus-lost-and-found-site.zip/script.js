// Campus Lost & Found: shared script for index.html, items.html and report.html
(function () {
  "use strict";
  var KEY = "lf-items-v1";
  var $ = function (id) { return document.getElementById(id); };
  var page = document.body.dataset.page;

  // ---------- Data ----------
  var seed = [
    ["Black Wallet","👛","Library","2026-10-05","lost"],["Blue Water Bottle","🥤","Cafeteria","2026-10-04","found"],
    ["Student ID Card","🪪","Main Block","2026-10-03","found"],["Wireless Earbuds","🎧","Computer Lab","2026-10-02","returned"],
    ["Grey Hoodie","🧥","Auditorium","2026-10-01","lost"],["Scientific Calculator","📓","Physics Lab","2026-09-30","lost"],
    ["House Keys","🔑","Parking Lot","2026-09-29","found"],["Laptop Charger","🎧","Library","2026-09-28","lost"],
    ["Umbrella","📦","Bus Stop","2026-09-27","returned"],["Spectacles Case","📦","Canteen","2026-09-26","found"],
    ["Notebook","📓","Seminar Hall","2026-09-25","lost"],["Phone Cover","📦","Sports Ground","2026-09-24","returned"]
  ].map(function (s, i) { return { id: i + 1, name: s[0], icon: s[1], loc: s[2], date: s[3], status: s[4], desc: "", contact: "" }; });

  function load() {
    try { var r = localStorage.getItem(KEY); if (r) { var d = JSON.parse(r); if (Array.isArray(d)) return d; } } catch (e) {}
    return seed.slice();
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch (e) {} }
  var items = load();

  // ---------- Helpers ----------
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(d) { var x = new Date(d + "T00:00:00"); return isNaN(x) ? d : x.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function sorted() { return items.slice().sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id; }); }
  function count(s) { return items.filter(function (i) { return i.status === s; }).length; }
  function toast(m) { var t = $("toast"); t.textContent = m; t.classList.add("on"); setTimeout(function () { t.classList.remove("on"); }, 2200); }
  function today() { var d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }

  function card(it, actions) {
    return '<div class="card"><div class="item-icon">' + esc(it.icon) + '</div><div class="item-details"><h3>' + esc(it.name) + '</h3><p>' +
      esc(it.loc) + ' • ' + fmt(it.date) + '</p>' + (it.desc ? '<p>' + esc(it.desc) + '</p>' : '') +
      (it.contact && actions ? '<p>Contact: ' + esc(it.contact) + '</p>' : '') + '</div><span class="status ' + it.status + '">' + cap(it.status) + '</span>' +
      (actions ? '<div class="actions">' + (it.status !== "returned" ? '<button class="small" data-act="ret" data-id="' + it.id + '">Mark returned</button>' : '') +
        '<button class="small" data-act="del" data-id="' + it.id + '" aria-label="Delete ' + esc(it.name) + '">Delete</button></div>' : '') + '</div>';
  }

  // ---------- Shared: nav, theme, reset ----------
  document.querySelectorAll("nav a").forEach(function (a) {
    if (a.dataset.p === page) { a.classList.add("active"); a.setAttribute("aria-current", "page"); }
  });
  $("menuBtn").onclick = function () { this.setAttribute("aria-expanded", $("nav").classList.toggle("open")); };

  var root = document.documentElement;
  function theme(t) { root.setAttribute("data-theme", t); $("themeBtn").textContent = t === "dark" ? "☀️" : "🌙"; }
  var st = null; try { st = localStorage.getItem("lf-theme"); } catch (e) {}
  theme(st || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
  $("themeBtn").onclick = function () {
    var n = root.getAttribute("data-theme") === "dark" ? "light" : "dark"; theme(n);
    try { localStorage.setItem("lf-theme", n); } catch (e) {}
  };
  $("resetBtn").onclick = function () {
    if (!confirm("Reset to the original demo items?")) return;
    items = seed.slice(); save(); if (render) render(); toast("Demo data restored");
  };

  // ---------- Page: home ----------
  var render = null;
  if (page === "home") {
    render = function () {
      $("reportedCount").textContent = items.length; $("lostCount").textContent = count("lost");
      $("foundCount").textContent = count("found"); $("returnedCount").textContent = count("returned");
      var q = $("homeQ").value.trim().toLowerCase();
      var list = sorted().filter(function (i) { return !q || (i.name + i.loc).toLowerCase().indexOf(q) > -1; }).slice(0, 4);
      $("recentReports").innerHTML = list.length ? list.map(function (i) { return card(i, false); }).join("") : '<p class="empty">No items match.</p>';
    };
    $("homeQ").oninput = render;
    $("homeSearch").onsubmit = function (e) { e.preventDefault(); location.href = "items.html?q=" + encodeURIComponent($("homeQ").value.trim()); };
  }

  // ---------- Page: items ----------
  if (page === "items") {
    var filter = "all";
    $("itemsQ").value = new URLSearchParams(location.search).get("q") || "";
    render = function () {
      var q = $("itemsQ").value.trim().toLowerCase();
      var list = sorted().filter(function (i) {
        return (filter === "all" || i.status === filter) && (!q || (i.name + i.loc + i.desc).toLowerCase().indexOf(q) > -1);
      });
      $("allItems").innerHTML = list.map(function (i) { return card(i, true); }).join("");
      $("empty").hidden = list.length > 0;
      $("itemsInfo").textContent = list.length + (list.length === 1 ? " item" : " items") + " shown";
    };
    $("itemsQ").oninput = render;
    $("chips").onclick = function (e) {
      var b = e.target.closest(".chip"); if (!b) return;
      document.querySelectorAll(".chip").forEach(function (c) { c.classList.remove("active"); });
      b.classList.add("active"); filter = b.dataset.f; render();
    };
    $("allItems").onclick = function (e) {
      var b = e.target.closest("button[data-act]"); if (!b) return;
      var id = +b.dataset.id;
      if (b.dataset.act === "ret") { items.forEach(function (i) { if (i.id === id) i.status = "returned"; }); toast("Marked as returned"); }
      else { if (!confirm("Delete this report?")) return; items = items.filter(function (i) { return i.id !== id; }); toast("Report deleted"); }
      save(); render();
    };
  }

  // ---------- Page: report ----------
  if (page === "report") {
    var type = "lost";
    $("fDate").value = today();
    $("seg").onclick = function (e) {
      var b = e.target.closest("button"); if (!b) return; type = b.dataset.t;
      document.querySelectorAll("#seg button").forEach(function (x) { x.classList.toggle("on", x === b); });
    };
    $("reportForm").onsubmit = function (e) {
      e.preventDefault();
      var id = items.reduce(function (m, i) { return Math.max(m, i.id); }, 0) + 1;
      items.push({ id: id, name: $("fName").value.trim(), icon: $("fIcon").value, loc: $("fLoc").value.trim(), date: $("fDate").value,
        status: type, desc: $("fDesc").value.trim(), contact: $("fContact").value.trim() });
      save(); location.href = "items.html";
    };
  }

  if (render) render();
})();
